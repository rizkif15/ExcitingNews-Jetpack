package com.rizkifauzi.excitingnews.model

class ListNews (
    val newsIdentity: Hero
)

